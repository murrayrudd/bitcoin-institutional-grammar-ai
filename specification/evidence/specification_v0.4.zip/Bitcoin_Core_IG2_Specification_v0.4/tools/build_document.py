"""Create the readable 0.4 specification using the prior research-report style."""
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]

def build():
    text=(ROOT/'protocol/codebook.txt').read_text()
    sections=[s.strip() for s in text.split('---PAGE---')]
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=Inches(.75);sec.bottom_margin=Inches(.75)
    sec.left_margin=Inches(.85);sec.right_margin=Inches(.85)
    sec.footer_distance=Inches(.35)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
        st=doc.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
        st.paragraph_format.widow_control=True
        rp=st.element.get_or_add_rPr()
        for el in list(rp):
            if el.tag==qn('w:rFonts'):
                for k in list(el.attrib):
                    if k.endswith('Theme'):del el.attrib[k]
        pp=st.element.get_or_add_pPr()
        for el in list(pp):
            if el.tag==qn('w:pBdr'):pp.remove(el)
    st=doc.styles['Normal'];st.font.size=Pt(11)
    st.paragraph_format.line_spacing=1.1;st.paragraph_format.space_after=Pt(7)
    for name,size in [('Title',22),('Heading 1',14),('Heading 2',12)]:
        st=doc.styles[name];st.font.size=Pt(size);st.font.bold=True
        st.paragraph_format.space_before=Pt(12 if name!='Title' else 0)
        st.paragraph_format.space_after=Pt(7);st.paragraph_format.keep_with_next=True
    doc.styles['Subtitle'].font.size=Pt(10)
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=footer.add_run('IG2 project specification 0.4  |  ');run.font.size=Pt(9)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    first=sections[0].splitlines()
    doc.add_paragraph(first[0],'Title')
    doc.add_paragraph('Project version 0.4  |  November 7 2026','Subtitle')
    # All normative codebook text is included; headings are identified by short standalone blocks.
    sections[0]='\n'.join(first[3:]).strip()
    for section in sections:
        blocks=section.split('\n\n')
        for i,b in enumerate(blocks):
            b=b.strip()
            if not b:continue
            if '\n' not in b and len(b)<90 and not b.endswith('.'):
                style='Heading 1' if i==0 else 'Heading 2'
                doc.add_paragraph(b,style)
            else:doc.add_paragraph(b)
    doc.core_properties.title='Bitcoin Core institutional analysis coding specification'
    doc.core_properties.subject='Project version 0.4 criteria and source-review workflow'
    doc.core_properties.author='Murray A. Rudd'
    output=ROOT/'report/Bitcoin_Core_IG2_Specification_v0.4.docx'
    doc.save(output);print(output)
    return output

if __name__=='__main__':build()

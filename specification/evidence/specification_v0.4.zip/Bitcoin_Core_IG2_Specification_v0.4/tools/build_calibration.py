"""Source-grounded development examples, not fresh coding or reference truth."""
import copy
import hashlib
import json
from pathlib import Path
from check_annotation import profile

ROOT=Path(__file__).resolve().parents[1]
P=json.loads((ROOT/'sources/round12_packet.original.json').read_text())
ENTRIES={x['source_id']:x for x in P['entries']}

def ev(sid, quote, start=None):
    text=ENTRIES[sid]['text'];i=text.index(quote) if start is None else start
    assert text[i:i+len(quote)]==quote
    return {'source_id':sid,'span':{'start':i,'end':i+len(quote),'quote':quote}}

def object_id(n):return f'https://github.com/bitcoin/bitcoin/pull/{n}'

def unit(uid,sid,quote,summary,itype='norm_candidate',grammar='regulative',force='recommendation'):
    e=ev(sid,quote)
    return {'unit_id':uid,**e,'parent_unit_id':None,'grammar':grammar,'speech_act':'asserted',
        'scope':'case_specific','components':[],
        'institution':{'type':itype,'dispute_present':False,'rationale':summary,'evidence':[e],
            'recognition':[],'authority_evidence':[],'standing_profile':{},'documentary_support':[],
            'application_evidence':[],'challenges':[],'type_alternatives':[]},
        'statement_target_level':'operational','observed_action_level':'operational',
        'level_rationale':'The focal claim concerns contribution conduct; the visible act is a contribution statement.',
        'complexity_flags':['none'],'alternative_interpretation':'','confidence':'plausible','uncertainty_reason':'',
        'record_role':'statement','parse_mode':'literal','deontic_force':force,
        'target_level_alternatives':[],'observed_level_alternatives':[],
        'level_evidence':{'target_activity':'Contribution conduct','observed_activity':'Discussion contribution',
            'arrangement':'Bitcoin Core contribution process','evidence':[e]},
        'presentation':{'quotation':'none','markup':'plain','rationale':'Retained source occurrence.'},
        'disposition_events':[],
        'proposition':{'summary':summary,'decision_object_id':None,'domain':'Bitcoin Core contribution process',
            'time_scope':'Retained source text; no unverified reconstruction of edit timing.',
            'identity_evidence':[],'qualifiers':[]}}

def component(u,symbol,text,source_quote=None,basis='explicit',role='local',note='',sid=None):
    sid=sid or u['source_id'];source_quote=source_quote or text
    # Search within the focal clause before any other occurrence.
    if sid==u['source_id'] and source_quote in u['span']['quote']:
        start=u['span']['start']+u['span']['quote'].index(source_quote)
    else:start=None
    e=ev(sid,source_quote,start)
    u['components'].append({'symbol':symbol,'text':text,'basis':basis,'evidence':[e],
        'inference_note':note,'occurrence_role':role,'governing_span':{'source_id':u['source_id'],'span':copy.deepcopy(u['span'])}})

def qualifier(u,sid,q,description):
    u['proposition']['qualifiers'].append({'description':description,'evidence':[ev(sid,q)],
        'attachment':'scope_note','linked_unit_id':None,'rationale':'This qualification constrains the focal proposition.'})

def recognition(sid,q,mode='expectation_application',basis='explicit',speaker='different_actor',kind='expectation_recognition'):
    return {'kind':kind,'target':'this_proposition','basis':basis,'evidence':[ev(sid,q)],
        'rationale':'The passage identifies the focal expectation and applies or recognizes it; interpretation remains source-reviewable.',
        'mode':mode,'speaker_relation':speaker,'independence_key':object_id(ENTRIES[sid]['pr']),
        'object_id':None,'identity_evidence':[]}

def build():
    packet=copy.deepcopy(P);packet['episode_id']='V04_DEVELOPMENT_EXERCISES';packet['project_codebook_version']='0.4'
    packet['selection_design']={'status':'development_only','scope':'Preselected focal propositions in the exercise key. Other text is retained context, not exhaustively coded. No independent coder run.'}
    for e in packet['entries']:
        e['object_id']=object_id(e['pr']) if e.get('pr') else None
    pp=ROOT/'calibration/packet.json';pp.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
    units=[];cases=[]
    def add(u,title,findings,reason,alternatives='',prohibited=''):
        u['institution']['standing_profile']=profile(u['institution'],u['record_role'])
        cited=set()
        def collect(x):
            if isinstance(x,dict):
                if 'source_id' in x:cited.add(x['source_id'])
                for v in x.values():collect(v)
            elif isinstance(x,list):
                for v in x:collect(v)
        collect(u)
        units.append(u);cases.append({'case_id':u['unit_id'],'title':title,'audit_findings':findings,
            'source_ids':sorted(cited),
            'focal_evidence':{'source_id':u['source_id'],'span':u['span']},
            'preferred_decision':reason,'defensible_alternatives':alternatives,'prohibited_inference':prohibited,
            'status':'Coordinator-authored calibration interpretation; not an independent reference annotation.'})

    u=unit('C01','32381-body','I still believe we should do #32359, as i signaled there.',
        'The author recommends proceeding with PR 32359 from within the body of PR 32381.','undetermined')
    u['speech_act']='proposed';u['proposition']['decision_object_id']=object_id(32359)
    u['proposition']['identity_evidence']=[ev('32381-body','#32359')]
    for sym,t in [('A','we'),('D','should'),('I','do'),('Bdir','#32359')]:component(u,sym,t)
    status=ev('M32359','"state": "closed",\n  "merged": false')
    u['disposition_events']=[{'kind':'recorded_closed_unmerged','target':'this_proposition','basis':'context_inferred',
        'evidence':[status],'rationale':'The recommended PR, 32359, closed unmerged. This does not prove rejection of its rationale.',
        'object_id':object_id(32359),'identity_evidence':[ev('M32359','"number": 32359'),ev('32381-body','#32359')]}]
    add(u,'Identity of the referenced proposal',['SA14','SA16'],'Attach M32359 to the recommendation concerning PR 32359.',
        'Retain PR 32381 closure separately as episode context.','Use M32381 as the recommended proposal outcome merely because both PRs closed unmerged.')

    q='IMO we should not have removal warnings if there is no current plan to actually remove them.'
    u=unit('C02','32714-body',q,'Contributors should avoid removal warnings when no current removal plan exists.')
    for sym,t in [('A','we'),('D','should not'),('I','have'),('Bdir','removal warnings'),('Cac','if there is no current plan to actually remove them')]:component(u,sym,t)
    qualifier(u,'32714-body','if there is no current plan to actually remove them','The advice is conditional on no current removal plan.')
    rq=ENTRIES['33453-body']['text'][ENTRIES['33453-body']['text'].index('This echo’s'):ENTRIES['33453-body']['text'].index('Deprecating the option in the future')]
    u['institution']['recognition']=[recognition('33453-body',rq)]
    u['proposition']['time_scope']='Recognition in the retained 33453 body; sentence-level insertion time is unknown.'
    u['uncertainty_reason']='The later edited body establishes a retained textual link but does not date its wording before merger.'
    add(u,'Recognition through attributed application',['SA07'],'Interpersonal recognition is supported by attribution, quotation, and application of the expectation.',
        'The degree of general acceptance remains unknown.','Require a binding rule before recognizing local support, or backdate the retained wording to PR creation.')

    q='In short, there must not be any translation source updates after the final translation string freeze.'
    u=unit('C03','33224-010',q,'Translation source updates are prohibited after the final translation string freeze.',force='prohibition')
    component(u,'D','must not');component(u,'I','update','updates','context_inferred','semantic_inference','Nominal updates is represented as an action; the role is reconstructed.')
    component(u,'Bdir','translation source',basis='context_inferred',role='semantic_inference',note='The nominal modifier supplies the target of the reconstructed update action.')
    component(u,'Cac','after the final translation string freeze')
    qualifier(u,'33224-010','after the final translation string freeze','The prohibition applies after the stated freeze.')
    cq='If this doc change is desired by contributors, and the 9 acks suggested that it is, then I think this workaround of modifying `bitcoin_en.ts` would be suitable.'
    u['institution']['challenges']=[{'aspect':'application','target':'this_proposition','evidence':[ev('33224-015',cq),ev('33224-015','However, I think there is a workaround to this issue.')],
        'rationale':'A proposed workaround challenges the categorical application while acknowledging the freeze purpose.'}]
    u['institution']['dispute_present']=True;u['institution']['type_alternatives']=['undetermined']
    u['alternative_interpretation']='A literal nominal-action parse can preserve the same prohibition; technical necessity versus institutional obligation remains a bounded alternative.'
    add(u,'Challenge to application',['SA25'],'Record the application challenge separately from documentary support and recognition.',
        'Keep norm_candidate versus technical necessity provisional.','Infer a formal waiver, actual translation processing, or rejection of the purpose of a freeze.')

    u=unit('C04','32406-252','please keep comments on topic','The addressed contributor is instructed to keep future comments on topic.','rule_candidate')
    u['speech_act']='proposed';u['deontic_force']='unresolved'
    component(u,'A','1440000bytes','@1440000bytes','context_inferred','context_reference','The explicit addressee supplies the inferred actor of the imperative.')
    component(u,'I','keep');component(u,'Bdir','comments');component(u,'Cex','on topic')
    sanction='Failure to keep future comments focused on review of the proposed changes will result in a temporary ban.'
    u['institution']['authority_evidence']=[ev('32406-252',sanction)]
    u['institution']['type_alternatives']=['norm_candidate']
    d='If moderation of individual posts fails, moderators will use warnings, timeouts and bans at increasing rates based on prior patterns of behavior.'
    u['institution']['documentary_support']=[{'coverage':'broader','claim_as_of':None,'source_as_of':'2024-08-14','date_basis':'pinned_revision','temporal_fit':'established',
        'evidence':[ev('D_MOD',d)],'rationale':'The pinned 2024 revision documents the general moderation procedure at that revision. It does not establish continuous validity through June 2025 or execution of this threatened ban.'}]
    u['proposition']['time_scope']='June 2025 warning; broader guidance is documented only at the supplied August 2024 revision.'
    qualifier(u,'32406-252',sanction,'The threat concerns future failure to keep review comments on topic; it does not report an executed ban.')
    add(u,'General guidance and a particular warning',['SA01','SA15'],'Retain broader documentary support and an attributable enforcement-claim candidate; application remains none.',
        'Norm candidate remains defensible if attributed authority is insufficient.','Convert generic moderation guidance or the warning into proof of an executed ban.')

    q='Reviews are weighted by the merit of their arguments, not the number of times they are posted.'
    u=unit('C05','32359-115',q,'Review weight follows argument merit rather than the number of repeated postings.',force='nondeontic')
    component(u,'I','weighted');component(u,'Bdir','Reviews',basis='context_inferred',role='semantic_inference',note='Passive subject supplies the object of the represented weighting action.')
    component(u,'Cex','by the merit of their arguments, not the number of times they are posted')
    qualifier(u,'32359-115','not the number of times they are posted','Repetition count is explicitly excluded as the basis of weight.')
    dt=ENTRIES['D_CONTRIB']['text'];ix=dt.lower().find('merit')
    # The later document supplies broad context. It cannot establish the exact earlier claim.
    ds='Open source often naturally\nrevolves around a meritocracy where contributors earn trust from the developer\ncommunity over time.'
    u['institution']['documentary_support']=[{'coverage':'broader','claim_as_of':'2025-04-29','source_as_of':'2025-06-09','date_basis':'pinned_revision','temporal_fit':'later_only',
        'evidence':[ev('D_CONTRIB',ds)],'rationale':'The later pinned guide supplies broader context, not contemporaneous proof of the exact April formulation.'}]
    nq='The technical content of those review comments is what matters, not how many are registered in what category.'
    u['institution']['recognition']=[recognition('32406-169',nq,mode='explicit_expectation',basis='context_inferred')]
    u['institution']['recognition'][0]['target']='broader_principle'
    u['institution']['recognition'][0]['rationale']='The later contributor reiterates the broader technical-content-over-count principle. It does not endorse the exact April clause about repeated postings; a separate, narrower principle record could receive interpersonal recognition.'
    u['alternative_interpretation']='A constitutive weighting representation can preserve meaning if it retains the same comparison object and exclusion.'
    add(u,'Dated support and bounded recognition',['SA02'],'Keep later-only documentary support distinct from recognition of the broader technical-content-over-count principle. Exact-proposition recognition remains unestablished for the clause about repeated postings.',
        'Constitutive representation can preserve the same content.','Backdate June documentation or silently broaden the focal claim to all meritocratic governance.')

    q='Only the majority decides the winner.'
    u=unit('C06','32359-227',q,'The speaker asserts exclusive majority determination of the winner in the quoted dispute.','undetermined',force='nondeontic')
    for sym,t in [('A','the majority'),('I','decides'),('Bdir','the winner')]:component(u,sym,t)
    qualifier(u,'32359-227','Only','The majority claim is exclusive.')
    cq=ENTRIES['32359-227']['text'].split('\r\n\r\n')[0]
    qualifier(u,'32359-227',cq,'The claim responds to a quoted characterization of opposing camps, not an independently established electorate.')
    u['statement_target_level']='unknown';u['target_level_alternatives']=['constitutional','epistemic']
    u['level_evidence']['target_activity']='Determining a winner; electorate, jurisdiction, and procedure are unresolved.'
    u['uncertainty_reason']='The passage supplies no operational definition of the majority or decision jurisdiction.'
    u['level_rationale']='The asserted decision principle is underspecified; the observable act is discussion.'
    add(u,'Higher governance levels and missing jurisdiction',['SA03','SA04','SA05'],'Use unknown for the target level and preserve the quoted premise and exclusive majority claim.',
        'Constitutional and epistemic readings remain explicit alternatives.','Infer a majority voting institution, a common decision object with every merit claim, or an observed constitutional change.')

    q='Personally, I think it\'s better to think of "deprecated" as meaning just "the devs recommend you don\'t use this feature".'
    u=unit('C07','32406-178',q,'The speaker proposes understanding deprecated as a developer recommendation against use.','constitutive_specification','constitutive','nondeontic')
    component(u,'E','deprecated');component(u,'F','meaning');component(u,'P',"the devs recommend you don't use this feature")
    qualifier(u,'32406-178','Personally, I think','The source presents a personal interpretive proposal.')
    r=recognition('32406-180',ENTRIES['32406-180']['text'],mode='unresolved',basis='unresolved')
    r['rationale']='Exact assent may recognize an institutional status or merely endorse terminology; the excerpt does not resolve the distinction.'
    u['institution']['recognition']=[r];u['institution']['type_alternatives']=['undetermined']
    u['alternative_interpretation']='Terminology endorsement without expectation recognition remains defensible.'
    add(u,'Status recognition and ordinary assent',['SA07'],'Retain unresolved recognition rather than treating bare assent as an automatic expectation-recognition event.',
        'Ordinary endorsement with no recognition support; bounded status-recognition reading with explicit rationale.','Treat agreement with a definition as proof of binding authority or a fixed removal timetable.')

    q="Smaller code code changes can be left to followups, as it's tedious to keep track of actual code review comments in this PR due to continued brigading."
    u=unit('C08','32406-149',q,'Small changes may be deferred to follow-ups in this review context.',force='permission')
    component(u,'D','can');component(u,'I','left');component(u,'Bdir','Smaller code code changes',basis='context_inferred',role='semantic_inference',note='Passive subject supplies the target of leaving changes to follow-ups.')
    component(u,'Cex','to followups')
    qualifier(u,'32406-149',"as it's tedious to keep track of actual code review comments in this PR due to continued brigading",'The source supplies a case-specific review burden as its rationale.')
    rq=ENTRIES['32406-151']['text'][ENTRIES['32406-151']['text'].index('Smaller code code changes'):]
    u['institution']['recognition']=[recognition('32406-151',rq,mode='explicit_expectation')]
    u['institution']['recognition'][0]['rationale']='The reply quotes the expectation, agrees, and states that nits should not block progress.'
    add(u,'Explicit local recognition',['SA20','SA24'],'Retain interpersonal recognition with both the quoted expectation and the nonblocking-nits response.',
        'Permission versus advisory recommendation may remain bounded.','Use the broad re-ACK alone as support for recognition of this particular expectation.')

    # Quotation convention fixture: both records are context, not separate institutional candidates.
    q="Did the NACK/ACK bot break? Doesn't seem to be updating? @DrahtBot"
    for uid,sid,role in [('C09a','32406-164','context'),('C09b','32406-165','quotation')]:
        u=unit(uid,sid,q,'Literal bot question retained for attribution.','not_applicable','not_institutional','nondeontic')
        u['record_role']=role;u['proposition']=None;u['speech_act']='question';u['statement_target_level']='not_applicable'
        if role=='quotation':u['presentation']['quotation']='repeated'
        add(u,'Literal question and repeated quotation',['SA11'],'Retain question speech act and distinguish repeated occurrence from an independent institutional statement.',
            '', 'Label the quoted question as an assertion or count it as independent endorsement.')

    relations=[{'from_unit_id':'C09b','to_unit_id':'C09a','type':'quotes','basis':'explicit',
                'rationale':'The repeated question preserves the original occurrence.','evidence':[ev('32406-165',q)],'logic_scope':'not_applicable'}]
    screens=[]
    for e in packet['entries']:
        ids=[u['unit_id'] for u in units if u['source_id']==e['source_id']]
        candidate=any(u['record_role']=='statement' and u['source_id']==e['source_id'] for u in units)
        screens.append({'source_id':e['source_id'],'disposition':'candidate' if candidate else ('context_only' if e['text'].strip() else 'empty'),
                        'reason':'Preselected development exercise; remaining source text is retained context, not an exhaustive extraction claim.','unit_ids':ids})
    evidence=[status]
    annotation={'schema_version':'0.4','run_id':'coordinator_authored_development_example','episode_id':packet['episode_id'],
        'packet_sha256':hashlib.sha256(pp.read_bytes()).hexdigest(),'entry_screening':screens,'units':units,'relations':relations,
        'episode_summary':{'observed_outcomes':[{'claim':'PR 32359 closed without merge.','evidence':evidence,
            'claim_parts':[{'text':'PR 32359 closed without merge.','evidence':evidence}]}],
            'mechanisms':[],'missing_evidence':['No sentence-level edit history for the retained 33453 body.'],
            'unresolved_questions':['These selected interpretations require source review and are not independent reference truth.']}}
    (ROOT/'calibration/annotation.json').write_text(json.dumps(annotation,ensure_ascii=False,indent=2)+'\n')
    # Additional judgment contrasts preserve findings that are not mechanical test targets.
    extra=[
        ('C10','Partial documentary coverage',['SA01'],'32359-115','There is no reason to leave unsubstantiated or repeat acks/nacks other than to spam the people subscribed to this repo.',
         'Distinguish the repetition limb from unsubstantiated ACK/NACK labels; the general guideline permits constructive reframing and some repetition.'),
        ('C11','Tentative qualification attachment',['SA12'],'32381-012',"If we're twiddling a knob to upset the least amount of people we probably should just twiddle it to the value we're considering (plus some buffer). Anything that results in 150 bytes or beyond?",
         'Attach the tentative 150-byte refinement, buffer, and purpose to the relevant recommendation, whether through a component, linked unit, or explicit scope note. Keep the question tentative.'),
        ('C12','Conditional future recommendation',['SA22'],'33453-body','Deprecating the option in the future, preferably with a removal schedule to better inform users, would still be possible.',
         'Preserve future possibility, preferably, and the information purpose. Do not turn these into an adopted removal schedule.'),
        ('C13','Value and application dispute',['SA26'],'32406-228','Open-source principles are a little more evolved than "the code is public" and require transparent decision-making that respects diverse input.',
         'Keep the transparency expectation, possible epistemic or collective-choice target, and observed discussion act separate. A response about application does not necessarily reject transparency.'),
    ]
    for cid,title,findings,sid,q,decision in extra:
        cases.append({'case_id':cid,'title':title,'audit_findings':findings,'source_ids':[sid],'focal_evidence':ev(sid,q),
            'preferred_decision':decision,'defensible_alternatives':'Retain source-supported alternatives and identify their effect on the institutional conclusion.',
            'prohibited_inference':'Do not use the case as evidence of fresh-model performance.','status':'Source interpretation exercise; not a full annotation fixture.'})
    (ROOT/'calibration/cases.json').write_text(json.dumps({'purpose':'Development interpretations and contrasts, not a gold standard or holdout.','cases':cases},ensure_ascii=False,indent=2)+'\n')
    return annotation

if __name__=='__main__':build()

"""Record the coordinator's development source review; no independent review claim."""
import json
from pathlib import Path
from check_annotation import check

ROOT=Path(__file__).resolve().parents[1]

def build():
    r=check(ROOT/'calibration/packet.json',ROOT/'calibration/annotation.json')
    (ROOT/'development/calibration_check.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    notes={
      'C01':'The focal text names 32359 despite appearing in 32381. The event cites M32359 with both closed and unmerged fields. No rejection or causal inference is added.',
      'C02':'The later body attributes, quotes, and applies the same conditional warning principle. The authors differ. Recognition concerns the retained body; insertion time and premerge influence remain unestablished.',
      'C03':'The nominal action parse marks reconstructed roles as inferred. The temporal condition remains attached. The workaround challenges categorical application while its introduction acknowledges the freeze purpose. No waiver or actual production processing is asserted.',
      'C04':'The addressed actor comes from the immediately preceding mention and is labeled contextual. The announced ban supplies an attributable enforcement claim, not execution. The broader moderation procedure is documented at its pinned 2024 revision; continuity through 2025 is not assumed.',
      'C05':'The April source distinguishes merit from repeated postings. The June guide is later-only and broader. The May statement recognizes a broader technical-content-over-count principle, so its target is broader_principle, not the exact repeated-postings clause. A separately bounded general-principle unit could receive interpersonal recognition.',
      'C06':'The exclusive majority assertion lacks an electorate and jurisdiction. Unknown target and bounded alternatives preserve that gap. The quoted camp premise is explicitly attached rather than inferred from its presence elsewhere in the source.',
      'C07':'The suggested deprecation definition may describe an institutional status; the personal proposal qualifier remains. Exact assent does not decide between status recognition and terminology endorsement, so recognition remains unresolved.',
      'C08':'The reply includes the quoted small-change expectation and the statement that nits should not block progress. This supports local recognition in this review context. Permission versus advisory recommendation remains a defensible interpretation question.',
      'C09a':'The literal bot question is retained as context with question speech act. No institutional candidate or independent recognition is asserted.',
      'C09b':'The repeated literal question links to C09a and retains question speech act. Quotation does not become an additional institutional candidate.',
      'C10':'The general guideline permits some repetition and constructive reframing. Its existence cannot document an absolute prohibition or every claim about unsubstantiated review labels.',
      'C11':'The complete quoted passage includes the tentative 150-byte refinement, buffer, and purpose. The rule requires explicit attachment to the relevant proposition but permits alternate representations.',
      'C12':'Future possibility, preferably, and the information purpose remain separate from a binding removal timetable. Different analytical layers can be represented if their relationship remains explicit.',
      'C13':'The transparency expectation concerns legitimate decision-making. Epistemic and collective-choice target readings remain possible; the visible contribution does not establish institutional adoption.'}
    resolutions=[]
    for i,f in enumerate(r['review_flags'],1):
        uid=f.get('unit_id')
        resolutions.append({'flag_index':i,'code':f['code'],'unit_id':uid,'disposition':'retained_with_scope_or_alternative',
            'reason':notes.get(uid,'The single summary outcome cites both status fields for the correct proposal. No mechanism or causal effect is asserted.')})
    result={
      'review_type':'Coordinator source-based development review',
      'independent':False,'fresh_coding_run':False,
      'reviewed_case_ids':list(notes),
      'reviewed_flag_codes':sorted({f['code'] for f in r['review_flags']}),
      'case_judgments':[{'case_id':k,'judgment':v} for k,v in notes.items()],
      'flag_resolutions':resolutions,
      'issues_resolved_during_development':[
        {'issue':'Earlier pinned guidance can be mistaken for proof of later continuous applicability.','resolution':'Added the temporal-continuity rule; C04 limits documentation to the supplied revision.'},
        {'issue':'A later statement about technical review content does not endorse every clause of an earlier repetition-count statement.','resolution':'Added broader_principle targeting and used it in C05; exact-proposition recognition remains unestablished.'},
        {'issue':'Matching exact text can still support an incorrect semantic label.','resolution':'Retained mandatory source-review flags and a regression case demonstrating that false documentary entailment can pass mechanical checks.'}],
      'remaining_alternatives':['C03 institutional obligation versus technical necessity','C05 preferred grammatical representation','C07 terminology assent versus institutional status recognition','C08 permission versus recommendation','C13 epistemic versus collective-choice target'],
      'readiness':'Development representation and mechanical safeguards are ready for prospective evaluation. Fresh independent application and comparative performance remain untested.'}
    (ROOT/'development/source_review.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':build()

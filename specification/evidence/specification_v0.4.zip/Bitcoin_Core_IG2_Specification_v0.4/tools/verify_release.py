"""Check release integrity and development-source consistency."""
import hashlib
import json
from pathlib import Path
from check_annotation import check

ROOT=Path(__file__).resolve().parents[1]

def verify():
    errors=[];checks=[]
    def require(condition,name):
        checks.append(name)
        if not condition:errors.append(name)
    provenance=json.loads((ROOT/'development/input_provenance.json').read_text())
    for x in provenance['files']:
        require(hashlib.sha256((ROOT/x['retained_path']).read_bytes()).hexdigest()==x['sha256'],'preserved input '+x['retained_path'])
    orig=json.loads((ROOT/'sources/round12_packet.original.json').read_text())
    packet=json.loads((ROOT/'calibration/packet.json').read_text())
    old={e['source_id']:e for e in orig['entries']};new={e['source_id']:e for e in packet['entries']}
    require(set(old)==set(new),'source inventory retained')
    for sid,e in old.items():
        require(all(new[sid].get(k)==v for k,v in e.items()),'original fields unchanged '+sid)
    anchors=0
    def walk(x):
        nonlocal anchors
        if isinstance(x,dict):
            if 'source_id' in x and 'span' in x:
                sid=x['source_id'];s=x['span'];anchors+=1
                require(sid in old and old[sid]['text'][s['start']:s['end']]==s['quote'],'case anchor '+str(anchors))
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    cases=json.loads((ROOT/'calibration/cases.json').read_text());walk(cases)
    require(len({c['case_id'] for c in cases['cases']})==len(cases['cases']),'unique case IDs')
    changes=json.loads((ROOT/'development/change_ledger.json').read_text())
    audit=json.loads((ROOT/'sources/round12_source_reconciliation.json').read_text())
    require({f for c in changes['changes'] for f in c['audit_findings']}=={x['audit_finding_id'] for x in audit['decisions']},'all 26 audit findings mapped')
    result=check(ROOT/'calibration/packet.json',ROOT/'calibration/annotation.json')
    require(result['status']=='pass','full-schema calibration passes')
    (ROOT/'development/calibration_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    review=json.loads((ROOT/'development/source_review.json').read_text())
    require(set(review['reviewed_case_ids'])=={c['case_id'] for c in cases['cases']},'coordinator review covers every calibration case')
    require(set(review['reviewed_flag_codes'])=={f['code'] for f in result['review_flags']},'coordinator review covers every semantic flag class')
    regress=json.loads((ROOT/'development/regression_results.json').read_text());require(regress['status']=='pass','regression suite passes')
    exclusion=json.loads((ROOT/'evaluation/known_exposure_inventory.json').read_text())
    require(exclusion['selection_allowed'] is False,'fresh-selection guard retained')
    # Manifest check does not change the manifest or version-controlled outputs.
    manifest_path=ROOT/'RELEASE_MANIFEST.json'
    if manifest_path.exists():
        m=json.loads(manifest_path.read_text())
        for x in m['files']:
            require(hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest()==x['sha256'],'release file '+x['path'])
    summary={'status':'pass' if not errors else 'fail','checks':len(checks),'errors':errors,
             'source_entries_unchanged':len(old),'case_evidence_anchors':anchors,
             'scope':'Integrity and declared coverage only; no independent semantic validation.'}
    print(json.dumps(summary,indent=2))
    if errors:raise SystemExit(1)
    return summary

if __name__=='__main__':verify()

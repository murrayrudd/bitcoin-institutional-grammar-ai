"""Build the change ledger and the explicitly incomplete exposure inventory."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def build():
    rules=[
      ('R01','Bound the proposition and verify decision-object identity','SA03 SA14 SA16 SA21','proposition; event object_id; metadata identity check','Criterion clarification and execution safeguard'),
      ('R02','Match documentary coverage and historical period','SA01 SA02 SA07','documentary_support; source and claim dates; backdating check','Criterion clarification'),
      ('R03','Separate assent from attributable recognition','SA02 SA07 SA15 SA20 SA24','recognition mode; speaker relation; episode key; recognition profile','Criterion clarification'),
      ('R04','Record support and challenges separately','SA03 SA08 SA19 SA25 SA26','standing_profile; challenges; derived dispute_present','Schema and criterion change'),
      ('R05','Classify institutional type after identifying its evidentiary basis','SA02 SA06 SA13 SA15 SA25','institution type alternatives; authority evidence; decision sequence','Criterion clarification'),
      ('R06','Attach all material qualifiers to the focal proposition','SA05 SA06 SA12 SA18 SA22 SA23','proposition qualifiers with component, linked-unit, or scope-note attachment','Coverage safeguard'),
      ('R07','Anchor components to their governing predicate','SA09 SA10 SA17','component governing_span; local-scope checks; source audit','Execution safeguard'),
      ('R08','Separate higher-level target claims from observed acts','SA04 SA26','separate target and observed alternatives; level evidence','Criterion clarification'),
      ('R09','Preserve literal question and quotation conventions','SA11','question review flag; existing speech-act rule retained','Execution safeguard'),
      ('R10','Support every material outcome and mechanism clause','SA08 SA16 SA20 SA21','claim_parts; parent evidence coverage; source audit','Execution safeguard'),
      ('R11','Distinguish semantic errors from defensible representations','SA04 SA05 SA06 SA10 SA12 SA13 SA17 SA18 SA22 SA23 SA24','masked alignment; source review diagnosis and effect fields','Evaluation clarification'),
      ('R12','Keep development, frozen evaluation, and reconciliation separate','SA01 SA02 SA03 SA04 SA05 SA06 SA07 SA08 SA09 SA10 SA11 SA12 SA13 SA14 SA15 SA16 SA17 SA18 SA19 SA20 SA21 SA22 SA23 SA24 SA25 SA26','prospective evaluation protocol; preserved originals; release snapshot','Workflow change')]
    changes=[{'rule_id':r,'change':c,'audit_findings':fs.split(),'implementation':i,'change_kind':k} for r,c,fs,i,k in rules]
    audit=json.loads((ROOT/'sources/round12_source_reconciliation.json').read_text())
    findings={d['audit_finding_id'] for d in audit['decisions']}
    assert findings=={f for x in changes for f in x['audit_findings']}
    ledger={'release':'0.4','status':'development release prepared for prospective evaluation','changes':changes,
            'covered_audit_findings':len(findings),'temporal_boundary':'RB01 is addressed by R02 and the C02 retained-body time qualification.',
            'prior_annotations_modified':False,'claim_of_improved_performance':False}
    (ROOT/'development/change_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
    packet=json.loads((ROOT/'sources/round12_packet.original.json').read_text())
    known={e['pr'] for e in packet['entries'] if e.get('pr')}
    known.update([18619,19827,20086])
    exposure={'status':'partial_requires_complete_project_inventory_before_fresh_selection',
              'known_episode_ids':[f'https://github.com/bitcoin/bitcoin/pull/{i}' for i in sorted(known)],
              'sources':['Round 12 supplied source metadata','Paper 1 Appendix C explicitly identifies 18619, 19827, and 20086'],
              'missing':'Complete earlier development and expansion case list plus any other content inspected by the project; the canonical sampling corpus is not bundled.',
              'selection_allowed':False}
    (ROOT/'evaluation/known_exposure_inventory.json').write_text(json.dumps(exposure,indent=2)+'\n')
    crosswalk={
       'version':'0.3 to 0.4','automatic_semantic_conversion_allowed':False,
       'fields':[
        {'old':'institution.standing','new':'standing_profile plus documentary_support, recognition, application_evidence, and challenges','action':'Reassess each dimension against sources. A legacy label alone is insufficient.'},
        {'old':'institution.dispute_present','new':'dispute_present derived from scoped challenges','action':'Identify the challenged proposition and aspect.'},
        {'old':'level_alternatives','new':'target_level_alternatives and observed_level_alternatives','action':'Assign each alternative to the correct analytical question.'},
        {'old':'recognition and disposition target','new':'target plus object_id and identity_evidence','action':'Verify the actual decision object; do not infer identity from containing PR.'},
        {'old':'component evidence','new':'component evidence plus governing_span','action':'Verify the specific predicate occurrence and contextual role.'},
        {'old':'implicit or elsewhere-stored qualifications','new':'proposition.qualifiers with explicit attachment','action':'Retain negation, conditionality, attribution, tentative status, and time.'},
        {'old':'outcome or mechanism evidence array','new':'claim_parts plus complete parent evidence','action':'Check every material clause.'}],
       'legacy_retention':'Preserve original files and source identifiers. Record each new interpretation in a separate versioned record with reason and evidence. Do not silently replace previous scores.',
       'priority_review':['U32 application challenge','U02 and N16 preferred grammar and alternatives','U25 conditional warning recognition','Any event whose containing PR differs from its referenced decision object'],
       'status':'Migration guidance only; no inherited manuscript or analysis record has been recoded in this release.'}
    (ROOT/'development/migration_guide.json').write_text(json.dumps(crosswalk,indent=2)+'\n')

if __name__=='__main__':build()

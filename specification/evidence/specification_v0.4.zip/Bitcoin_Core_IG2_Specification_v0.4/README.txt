BITCOIN CORE INSTITUTIONAL ANALYSIS SPECIFICATION 0.4
Development release prepared for fresh evaluation
November 7 2026

Purpose
Version 0.4 makes the project's institutional coding criteria more explicit and
adds checks for failures exposed by the Round 12 overlap study. It retains the
inherited IG2 grammar. It separates documentary coverage, recognition,
application, and challenge instead of forcing them into one standing category.

Read protocol/codebook.txt for the complete rules and the accompanying DOCX for
the same specification in a readable document. protocol/annotation_schema.json
defines the output structure. The change ledger maps all 26 Round 12 audit
findings to twelve groups of changes. Original 0.3 files remain in baseline_v03.

What this release establishes
The development cases and regression tests exercise the new representation and
mechanical safeguards on known material. They do not establish that a fresh AI
coder applies the criteria reliably or that 0.4 improves accuracy. No new model
coding run, cross-model comparison, or human reference annotation is claimed.
The prospective evaluation design is prepared, but no fresh cases are selected.

Core files
protocol/codebook.txt                  Complete 0.4 instructions
protocol/annotation_schema.json        Full machine-readable schema
protocol/coder_instructions.txt        First output, checking, and self-review
protocol/source_review_instructions.txt Source audit of agreement and disagreement
protocol/alignment_instructions.txt    Proposition matching before label comparison
tools/check_annotation.py              Structural and evidence-scope checker
calibration/cases.json                 Source-grounded interpretation exercises
calibration/annotation.json            Full-schema examples for selected propositions
calibration/packet.json                Identical source text with explicit object IDs
development/change_ledger.json         Findings-to-change mapping
development/migration_guide.json       Source-based migration guidance
development/regression_results.json    Mechanical regression results
development/source_review.json        Coordinator review and remaining ambiguities
evaluation/protocol.json               Prospective paired overlap design
evaluation/known_exposure_inventory.json Partial exposure list and selection guard
RELEASE_MANIFEST.json                  Release file identities

Calibration scope
The full-schema example deliberately represents eight selected statements and
two context or quotation records. All 98 source entries remain available as
context. Screening in this example refers to these preselected exercises; it is
not an exhaustive extraction of those 98 entries. Fresh evaluation coders must
screen and annotate their complete assigned packet. The case ledger also
includes interpretation contrasts that do not have full-schema annotation units.

Use
Requirements: Python 3 and jsonschema. Document generation additionally uses
python-docx. From this directory:
    python tools/check_annotation.py calibration/packet.json calibration/annotation.json
    python tools/test_specification.py
    python tools/verify_release.py

Rebuild development outputs, if intentionally editing a new version:
    python tools/build_schema.py
    python tools/build_codebook.py
    python tools/build_calibration.py
    python tools/build_development_records.py
Original inputs and previously reported agreement remain unchanged. New semantic
judgments require source review; schema conformance alone is insufficient.

Prospective evaluation
Complete and freeze the project-wide exposure inventory and candidate-source
inventory before selecting the fresh sample. The supplied exposure list is
explicitly partial and sets selection_allowed=false. The design compares three
fresh contexts per version across three episodes, followed by source review.
The plan does not require mandatory human coding or claim independent statistical
observations. Human judgment remains responsible for values and policy choices.

Interpretive boundaries
Documentary coverage may be broader than the focal statement. A later source
cannot establish an earlier statement's standing without supporting history.
Recognition requires the relevant expectation and attributable uptake; ordinary
assent and same-speaker repetition have separate meanings. A challenge to a rule's
application can coexist with recognition of its purpose. Repository integration
does not establish Bitcoin network adoption, and an announced sanction does not
establish execution. Unresolved alternatives remain visible.
